`use strict`

// После загрузки страницы

document.addEventListener("DOMContentLoaded", function (e) {

    const filterContainer = document.querySelector(".product-section__filter");
    // Категории (кнопки)
    const categoryContainer = document.querySelector(".product-section__filter-category-wrapper");
    const categoryButtons = document.querySelectorAll('.filters-category-btn');

    // Инпуты цены
    const priceMinInput = document.querySelector('#filter-price-min');
    const priceMaxInput = document.querySelector('#filter-price-max');
    const priceForm = document.querySelector('.filter__price-form');

    // Чекбоксы брендов
    const brandCheckboxes = document.querySelectorAll('.filter__brands-list input[type="checkbox"]');

    // Чекбоксы цветов
    const colorCheckboxes = document.querySelectorAll('.filter__color-list input[type="checkbox"]');

    // Контейнер карточек
    const productsContainer = document.querySelector('.product-section__wrapper');

    // Кнопка "Показать ещё" (если будешь реализовывать)
    const showMoreBtn = document.querySelector('.product-section__btn-show-more');


    let objFilter = {
        category: [],
        brands: [],
        colors: [],
    };

    let flagFilter = false;


   class Product {
    constructor(id, title, price, brand, category, color, thumbnail, descr) {
        this.id = id;
        this.title = title;
        this.price = price;
        this.brand = brand;
        this.category = category;
        this.color = color;
        this.thumbnail = thumbnail;
        this.descr = descr;
    }
   }

   class ProductManager {
    allProduct = [];
    
    constructor() {
        this.loadProducts();
        // this.filterManager = new FilterManager();

    }

    // Загрузка с API
    loadProducts(objFilter, flagF) {
        const categories = [
            'womens-dresses',
            'womens-shoes',
            'womens-watches',
            'womens-bags',
            'tops',
            'mens-shirts',
            'mens-shoes',
            'mens-watches',
            'smartphones',
            'laptops',
            'lighting'
        ];

        const fetchPromises = categories.map(category => {
            return fetch(`https://dummyjson.com/products/category/${category}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Ошибка сети: ' + response.status);
                    }
                    return response.json();
                })
                .then(data => data.products)
                .catch(error => {
                    console.error('Произошла ошибка: ', error.message);
                    return [];
                });
        });

        Promise.all(fetchPromises)
        .then(products => {
            this.allProduct = products.flat();
            if (!flagFilter) {
                this.renderProducts(this.allProduct);
            }
                const productsFilters = this.allProduct.filter(prod => {
                   return prod.category === objFilter.category.includes(prod.category);
                });
            this.renderProducts(productsFilters);
        


           

                
            
        });

    }




    renderProducts(products) {
        products.forEach(function (prod) {
        const html = `
            <div class="product-section__wrapper-card product-card" id="${prod.id}">
                <div class="product-card__top">
                    <img class="product-card__top-img" src="${prod.images[0]}" alt="">
                </div>
                <div class="product-card__top-content">
                    <div class="product-card__detail">
                        <a href="product-detail.html">${prod.title}</a>
                    </div>

                    <div class="product-card__price">${Math.round(prod.price * 90)} ₽уб</div>
                    <button class="product-card__btn-add-to-cart">В корзину</button>
                    <div class="product-card__hover">
                        <div class="product-card__preview-description">${prod.description}</div>
                    </div>
                </div>
            </div>
        
        `;

        productsContainer.insertAdjacentHTML("afterbegin", html);

        });



    }

    clearProducts() {

    }

   }

   class FilterManager {

    constructor(productManager) {
        this.productManager = productManager;
        categoryContainer.addEventListener("click", this.getActiveCategory.bind(this));

    }

    getActiveCategory(e) {
        const target = e.target;
        // Если кликнули по кнопке категории
        if (target.classList.contains("filters-category-btn")) {

        
            // Если кликнули по кнопке категории, которая не активна
             if (!objFilter.category.includes(target.dataset.category)) {
                objFilter.category.push(target.dataset.category);

                console.log("Если нет совпадений");
                console.log(objFilter.category);
                this.productManager.loadProducts(objFilter, true);

                target.classList.toggle("filters-btn_active");
            } else if (objFilter.category.includes(target.dataset.category)) { 

                objFilter.category = objFilter.category.filter(function (elem) {
                    return elem != target.dataset.category;
                });

                console.log("Если совпадения");
                console.log(objFilter.category);

                target.classList.toggle("filters-btn_active");
                this.productManager.loadProducts(objFilter, true);
            }

                


            
            // if (!this.objFilter.category.includes(target.dataset.category)) {
            //     this.objFilter.category.push(target.dataset.category);
            //     console.log("Если нет совпадений: " + this.objFilter);
            //     console.log(this.objFilter);
            //     target.classList.toggle("filters-btn_active");
            //     this.productManager.filterProducts(this.objFilter, true);
                
            // } else if (this.objFilter.category.includes(target.dataset.category)) {
            //     console.log("Есть совпадения: " + this.objFilter);
            //     console.log(this.objFilter);
            //     const index = this.objFilter.category.indexOf(target.dataset.category);
            //     this.objFilter.category.slice(index, 1);
            //     console.log("Есть совпадения 2: " + this.objFilter);
            //     console.log(this.objFilter);
            //     target.classList.toggle("filters-btn_active");
            //     this.productManager.filterProducts(this.objFilter, true);
            // }
        }
    }

   }


const productManager = new ProductManager();
const filterManager = new FilterManager(productManager);

    


    

});